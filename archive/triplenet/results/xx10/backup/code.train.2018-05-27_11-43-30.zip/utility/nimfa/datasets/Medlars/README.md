# Medlars

Dataset is at: http://web.eecs.utk.edu/research/lsi. This is a collection of 1033 medical abstracts. 

Directory structure should look like:

    datasets/
      Medlars/
        med.all
      [...]
