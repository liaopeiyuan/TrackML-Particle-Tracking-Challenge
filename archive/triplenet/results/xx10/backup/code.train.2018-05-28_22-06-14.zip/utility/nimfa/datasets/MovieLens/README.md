# Movielens

Dataset is at: http://www.grouplens.org/node/12. Select the stable benchmark dataset with 100000 
ratings from 1000 users on 1700 movies.  

Directory structure should look like:

    datasets/
      MovieLens/
        ua.base
        ua.test
        ub.base
        ub.test
        [...]
      [...]
