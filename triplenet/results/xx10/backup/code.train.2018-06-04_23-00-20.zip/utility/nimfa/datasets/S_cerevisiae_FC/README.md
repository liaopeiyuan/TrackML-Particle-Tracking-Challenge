# S. Cerevisiae MIPS's molecular functions 

Dataset is at: http://dtai.cs.kuleuven.be/clus/hmc-ens. 

Directory structure should look like:

    datasets/
      S_cerevisiae_FC/
        hom_yeast_FUN/
            hom_yeast_FUN.test.arff
            hom_yeast_FUN.train.arff
            hom_yeast_FUN.valid.arff
        pheno_yeast_FUN/
            pheno_yeast_FUN.test.arff
            pheno_yeast_FUN.valid.arff
            pheno_yeast_FUN.train.arff
        seq_yeast_FUN/
            seq_yeast_FUN.train.arff
            seq_yeast_FUN.test.arff
            seq_yeast_FUN.valid.arff
        struc_yeast_FUN/
            struc_yeast_FUN.train.arff
            struc_yeast_FUN.test.arff
            struc_yeast_FUn.valid.arff
        [...]
      [...]
